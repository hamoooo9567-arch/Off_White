import { useState } from 'react';
import {
  ArrowRight,
  ChevronDown,
  Instagram,
  MapPin,
  Menu,
  X,
} from 'lucide-react';

type Language = 'en' | 'ar';

const copy = {
  en: {
    navShop: 'Shop', navStory: 'Our Story', navVisit: 'Visit Us',
    heroEyebrow: 'Couture & Boutique',
    heroTitle: 'Quiet luxury, made for every day.',
    heroText: 'Thoughtful womenswear in soft neutrals, relaxed silhouettes, and timeless details.',
    shopNow: 'Shop the collection', viewLook: 'View the look',
    collection: 'The Collection',
    collectionText: 'Easy pieces designed to move with you from morning plans to evening moments.',
    featured: 'Featured look', productName: 'Olive Utility Set',
    productDesc: 'Relaxed overshirt and wide-leg trousers in a muted olive tone.',
    discover: 'Discover', story: 'Our Story',
    storyText: 'Off White is a women’s clothing boutique built around effortless dressing. We pair understated colors with comfortable cuts and small details that make everyday outfits feel considered.',
    visit: 'Visit the boutique', address: 'Egypt · El Beheira · Kafr El Dawar',
    visitText: 'Come see the collection in person and discover your next favorite piece.',
    language: 'العربية', footer: 'Off White · Couture & Boutique', instagram: 'Follow us',
  },
  ar: {
    navShop: 'المجموعة', navStory: 'قصتنا', navVisit: 'زورينا',
    heroEyebrow: 'كوتور وبوتيك', heroTitle: 'أناقة هادئة لكل يوم.',
    heroText: 'أزياء نسائية بألوان هادئة، قصّات مريحة، وتفاصيل خالدة.',
    shopNow: 'تصفحي المجموعة', viewLook: 'شاهدي الإطلالة',
    collection: 'المجموعة',
    collectionText: 'قطع سهلة وأنيقة تناسب يومك من الصباح وحتى المساء.',
    featured: 'إطلالة مميزة', productName: 'طقم زيتي عملي',
    productDesc: 'قميص واسع وبنطلون واسع بقصة مريحة باللون الزيتي الهادئ.',
    discover: 'اكتشفي', story: 'قصتنا',
    storyText: 'أوف وايت هو بوتيك للأزياء النسائية يعتمد على الأناقة السهلة. نجمع الألوان الهادئة مع القصّات المريحة والتفاصيل البسيطة لصناعة إطلالات يومية أنيقة.',
    visit: 'زورينا', address: 'مصر · البحيرة · كفر الدوار',
    visitText: 'زورينا لاكتشاف المجموعة واختاري قطعتك المفضلة القادمة.',
    language: 'English', footer: 'أوف وايت · كوتور وبوتيك', instagram: 'تابعينا',
  },
};

function App() {
  const [language, setLanguage] = useState<Language>('en');
  const [menuOpen, setMenuOpen] = useState(false);
  const t = copy[language];
  const isArabic = language === 'ar';

  const scrollTo = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
    setMenuOpen(false);
  };

  return (
    <div className={`site ${isArabic ? 'rtl' : ''}`} dir={isArabic ? 'rtl' : 'ltr'}>
      <header className="topbar">
        <button className="brand" onClick={() => scrollTo('home')} aria-label="Off White home">
          <img src="/resources/off-white-logo.jpg" alt="Off White logo" />
        </button>

        <nav className={`desktop-nav ${menuOpen ? 'mobile-open' : ''}`}>
          <button onClick={() => scrollTo('collection')}>{t.navShop}</button>
          <button onClick={() => scrollTo('story')}>{t.navStory}</button>
          <button onClick={() => scrollTo('visit')}>{t.navVisit}</button>
        </nav>

        <div className="header-actions">
          <button className="language-button" onClick={() => setLanguage(isArabic ? 'en' : 'ar')}>
            <span>{isArabic ? 'EN' : 'ع'}</span>{t.language}
          </button>
          <button className="menu-button" onClick={() => setMenuOpen(!menuOpen)} aria-label="Toggle menu">
            {menuOpen ? <X size={21} /> : <Menu size={21} />}
          </button>
        </div>
      </header>

      <main>
        <section className="hero" id="home">
          <div className="hero-copy">
            <p className="eyebrow">{t.heroEyebrow}</p>
            <h1>{t.heroTitle}</h1>
            <p className="hero-text">{t.heroText}</p>
            <div className="hero-actions">
              <button className="primary-button" onClick={() => scrollTo('collection')}>
                {t.shopNow} <ArrowRight size={17} />
              </button>
              <button className="text-button" onClick={() => scrollTo('collection')}>
                {t.viewLook} <ChevronDown size={16} />
              </button>
            </div>
          </div>
          <div className="hero-image-wrap">
            <div className="hero-image">
              <img src="/resources/off-white-clothes.jpg" alt={t.productName} />
            </div>
            <div className="floating-note"><span>01</span><p>{t.featured}</p></div>
          </div>
        </section>

        <section className="collection section" id="collection">
          <div className="section-heading">
            <div><p className="eyebrow">01 · {t.navShop}</p><h2>{t.collection}</h2></div>
            <p>{t.collectionText}</p>
          </div>

          <div className="product-grid">
            <article className="product-card featured-card">
              <div className="product-image">
                <img src="/resources/off-white-clothes.jpg" alt={t.productName} />
                <span className="product-tag">{t.featured}</span>
              </div>
              <div className="product-info">
                <div><h3>{t.productName}</h3><p>{t.productDesc}</p></div>
                <button onClick={() => scrollTo('visit')} aria-label={t.discover}><ArrowRight size={19} /></button>
              </div>
            </article>

            <article className="editorial-card">
              <div className="editorial-copy">
                <p className="eyebrow">Off White</p>
                <h3>{isArabic ? 'تفاصيل بسيطة. حضور واضح.' : 'Simple details. Distinct presence.'}</h3>
                <button className="text-button" onClick={() => scrollTo('story')}>
                  {t.discover} <ArrowRight size={16} />
                </button>
              </div>
            </article>
          </div>
        </section>

        <section className="story section" id="story">
          <div className="story-mark">OW</div>
          <div className="story-copy">
            <p className="eyebrow">02 · {t.navStory}</p>
            <h2>{t.story}</h2>
            <p>{t.storyText}</p>
          </div>
        </section>

        <section className="visit section" id="visit">
          <div className="visit-panel">
            <div>
              <p className="eyebrow">03 · {t.navVisit}</p>
              <h2>{t.visit}</h2>
              <p>{t.visitText}</p>
            </div>
            <div className="address">
              <MapPin size={20} />
              <div><strong>{t.address}</strong><span>Kafr El Dawar, El Beheira, Egypt</span></div>
            </div>
            <button className="primary-button" onClick={() => window.open('https://www.google.com/maps/search/?api=1&query=Kafr+El+Dawar+El+Beheira+Egypt', '_blank')}>
              {isArabic ? 'افتحي الموقع' : 'Open location'} <ArrowRight size={17} />
            </button>
          </div>
        </section>
      </main>

      <footer>
        <div className="footer-brand">
          <img src="/resources/off-white-logo.jpg" alt="Off White" />
          <span>{t.footer}</span>
        </div>
        <button className="instagram-link" onClick={() => window.open('https://www.instagram.com/', '_blank')}>
          <Instagram size={17} /> {t.instagram}
        </button>
        <span className="copyright">© {new Date().getFullYear()} Off White</span>
      </footer>
    </div>
  );
}

export default App;
