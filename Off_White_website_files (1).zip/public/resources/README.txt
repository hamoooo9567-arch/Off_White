The deployed Off White site uses two original image assets here:
off-white-logo.jpg
off-white-clothes.jpg

Upload those two JPG files into this folder from the original images you supplied for the website.
